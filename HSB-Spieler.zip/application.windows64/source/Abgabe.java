import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Abgabe extends PApplet {

// setup
PImage img; // Hauptbild

boolean auto = false; // Automodus an/aus

int[] tempPix; // aktuell bearbeuiteter Pixel
PVector point;
PVector mouse;

// menus;
WMenu help;
WMenu attributes;

// calculations
int[] hsbBool = {1,0,0}; // Welcher HSB-Modus

boolean positiv = true; //rechts oder links-klick

float tempHue;
float tempSat;
float tempBri;

int radius = 50;
float vecDis; // Vektor Distanz zu Mitte
float disMulti; // daraus herausfolgender Multiplikator

int currPix = 0; // für pixels[]
float strength = 3;
float autoStrength = 1.1f;

//// SETTINGS + START ////
public void settings(){
  img = loadImage("Bild.PNG");
  
  float b = img.height;
  float c = img.width;
    
  float a = 1000 * (c/b);
  float a2 = 700 * (b/c);
  
  // Abscicherung das nicht zu groß für Monitor
  if(img.width > displayWidth){
    size(PApplet.parseInt(a) , 1000);
    } else if (img.height > displayHeight){
      size(700, PApplet.parseInt(a2));
        } else size(img.width,img.height);
  
  //size(img.width,img.height); // Normal falls oben nicht mehr funktioniert
}

public void setup(){
  image(img,0,0,width,height);
  noStroke();
  colorMode(HSB,360,100,100);
  
  point = new PVector(0,0);
  mouse = new PVector(0,0);
  
  tempPix = new int[width*height];
  
  PixelsSaving();
  
  // Menüs intitialisieren
  int rA = 20; // rA = RandAbstand 
  help = new WMenu(width-rA-200, rA, 200, 293, true);
  attributes = new WMenu(rA, rA, 230, 117, false);
}

//// DRAW ////
public void draw(){
  PixelsLoading(); // um vorher gesicherte Pixels laden
  loadPixels(); // für Pixelbearbeitung
 
  // Automodus
  if(auto && hsbBool[0] == 1){
    for(int i = 0; i < pixels.length; i++){
      tempHue = hue(pixels[i]); // einzelne Komponenten aktueller Farbe
      tempSat = saturation(pixels[i]);
      tempBri = brightness(pixels[i]);
      
      pixels[i] = color(tempHue+hsbBool[0]*autoStrength,tempSat+hsbBool[1]*autoStrength,tempBri+hsbBool[2]*autoStrength);
    }
  }

  if(mousePressed){
    if(mouseButton == LEFT)
      positiv = true;
    if(mouseButton == RIGHT)
      positiv = false;
      
      //loadPixels();
      mouse.x = mouseX; mouse.y = mouseY;
      for(int i = mouseX-radius; i < mouseX+radius; i++){
        for(int j = mouseY-radius; j < mouseY+radius;j++){
          if(i > 0 && i < width && j > 0 && j < height){ // Abfrage nicht außerhalb des Bildes
          
            point.x = i; point.y = j;
          
            if(point.dist(mouse) < radius){ // Kreisradius
              currPix = j * width + i; // Rechnung welcher pixel laut i und j
              
              tempHue = hue(pixels[currPix]); // temporäre HSB zum Rechnen
              tempSat = saturation(pixels[currPix]);
              tempBri = brightness(pixels[currPix]);
              
              if(tempHue <= 1 && positiv == false){ // wenn rechtsklick um h zu verringern
                tempHue = 360 - tempHue;
              }
              
              vecDis = point.dist(mouse); // Distanz der Vektoren
              disMulti = map(vecDis,0,radius,0,0.8f); // Verhältnis zur Mitte
              
              if(positiv){ // finale Rechnung je nach plus oder minus
                pixels[currPix] = color(tempHue+hsbBool[0]*(strength*(1-disMulti)), tempSat+hsbBool[1]*(strength*(1-disMulti)), tempBri+hsbBool[2]*(strength*(1-disMulti)));  // neue Farbe
              } else {
                pixels[currPix] = color(tempHue-hsbBool[0]*(strength*(1-disMulti)), tempSat-hsbBool[1]*(strength*(1-disMulti)), tempBri-hsbBool[2]*(strength*(1-disMulti)));
              }
            }
          }
        }
      } 
  }
  updatePixels();
  
  // Keys //
  if(keyPressed){
    switch(key){
      case 'x': // Stärke größer
        strength += 0.05f;
        if(strength > 10) strength = 10;
        break;
        
      case 'y': // Stärke kleiner
        strength -= 0.05f;
        if(strength < 1) strength = 1;
        break;
        
      case 'v': // Stärke größer
        autoStrength += 0.05f;
        if(autoStrength > 10) autoStrength = 10;
        break;
        
      case 'c': // Stärke kleiner
        autoStrength -= 0.05f;
        if(autoStrength < 1) autoStrength = 1;
        break;
        
      case 'r': // reset
        reseto();
        break;
        
      case 'w': // weißer Hintergrund
        whiteBg();
        break;
    }
  }
  
  PixelsSaving(); // sodass Kreis und co. nicht mitgespeichert werden // nach Keys weil Keys-Veränderung gewollt
  
  // Menüs update //
  help.update(1, hsbBool, strength, autoStrength);
  attributes.update(2, hsbBool, strength, autoStrength);
  
  // Anzeigekreis //
  pushStyle();
  noFill();
  stroke(0,0,20,60);
  circle(mouseX,mouseY,radius*2);
  popStyle();
  
  // Debug //
  /*pushStyle();
  popStyle();*/
  //println(frameRate);
}

//// METHODEN ////
public void keyReleased(){
    switch(key){
      case 'f': // speichern
        save("newImage.png");
        println("gespeichert");
        break;
        
      case 'a': // automodus
        auto = !auto;
        break;
        
      case '1': // auf H umschalten
        changeHSB(1);
        break;
        
      case '2': // auf S umschalten
        changeHSB(2);
        break;
        
      case '3': // auf B umschalten
        changeHSB(3);
        break;
        
      case 'h': // Hilfe
        help.changeActive();
        break;
        
      case 'e': // Attribute
        attributes.changeActive();
        break;
    }
}

  public void mouseWheel(MouseEvent eve){ // Radius größer/kleiner
    float e = eve.getCount();
    radius += (-e)*3;
    
    if(radius < 10) radius = 10;
    if(radius > width) radius = width;
  } 

  public void reseto(){ // Bild auf Standard zurück
    image(img,0,0,width,height);
  }
  
  public void changeHSB(int i){ // HSB Wechsel
    switch(i){
      case 1:
        hsbBool[0] = 1; hsbBool[1] = 0; hsbBool[2] = 0;
        break;
        
      case 2:
        hsbBool[0] = 0; hsbBool[1] = 1; hsbBool[2] = 0;
        break;
        
      case 3:
        hsbBool[0] = 0; hsbBool[1] = 0; hsbBool[2] = 1;
        break;
    }
  }
  
  public void whiteBg(){
    fill(0,0,100);
    rect(0,0,width,height);
  }
  
  public void PixelsLoading(){
    loadPixels();
    for(int i = 0; i < width*height; i++){
      pixels[i] = tempPix[i];
    }
    updatePixels();
  }
  
  public void PixelsSaving(){
    loadPixels();
    for(int i = 0; i < width*height; i++){
      tempPix[i] = pixels[i];
    }
  }
  
class WMenu{
  PVector currPosition;
  
  boolean active;
  int startPosition;
  int endPosition;
  int falseInt = -300;
  
  int fieldWidth;
  int fieldHeight;
  int bW = 3;
  int bR = 15;

  int textSize = 15;
  int textHelper = 25;
  int tA = 15;
  
  // Konstruktor
  WMenu(int posX, int posY, int widtho, int heighto, boolean activo ){
    active = activo;
    
    if(active){
      currPosition = new PVector(posX, posY);
    } else currPosition = new PVector(posX, falseInt);
    
    fieldWidth = widtho;
    fieldHeight = heighto;
    
    startPosition = posY;
    endPosition = falseInt;
  }
  
  public void update(int whichMenu, int[] arrHSB, float strength, float autoStrength){
      if(this.active){
        if(currPosition.y <= startPosition )//startPos
          currPosition.y += 6;
      } else {
        if(currPosition.y >= endPosition)
          currPosition.y -= 6;
      }
      
      pushStyle();
      //Rahmen
      fill(0,100,0,70);
      rect(currPosition.x -bW, currPosition.y -bW, (fieldWidth+2*bW), (fieldHeight+2*bW), bR, bR, bR, bR);
      
      // Textfläche
      fill(360,0,100);
      rect(currPosition.x, currPosition.y, fieldWidth, fieldHeight, bR, bR, bR, bR);
      
      fill(0);
      textSize(textSize);
      switch(whichMenu){
        case 1: // Hilfe
          pushStyle();
          textAlign(CENTER);
          textSize(25);
          
          // Überschrift
          text("Hilfe", (currPosition.x + fieldWidth/2), (currPosition.y + 30));
          popStyle();
          
          // Text
          text("'h' Hilfe ein/aus ", currPosition.x + tA, currPosition.y + 2.2f* textHelper);
          text("'e' Attribute ein/aus ", currPosition.x + tA, currPosition.y + 3.2f* textHelper);
          text("'1' für Hue", currPosition.x + tA, currPosition.y + 4.2f* textHelper);
          text("'2' für Saturation", currPosition.x + tA, currPosition.y + 5.2f* textHelper);
          text("'3' für Brightness", currPosition.x + tA, currPosition.y + 6.2f* textHelper);
          text("'y'/'x' Stärke -/+", currPosition.x + tA, currPosition.y + 7.2f* textHelper);
          text("'c'/'v' Auto-Stärke -/+", currPosition.x + tA, currPosition.y + 8.2f* textHelper);
          text("Mausrad für Kreis", currPosition.x + tA, currPosition.y + 9.2f* textHelper);
          text("'w' für weiße Fläche", currPosition.x + tA, currPosition.y + 10.2f* textHelper);
          text("'s' für Bild speichern", currPosition.x + tA, currPosition.y + 11.2f* textHelper);
          break;
        
        case 2: // Eigenschaften
          pushStyle();
          textAlign(CENTER);
          textSize(25);
          
          // Überschrift
          text("Attribute", (currPosition.x + fieldWidth/2), (currPosition.y + 30));
          popStyle();
          
          // Text
          if(hsbBool[0] == 1){
            text("Hue-Modus ist aktiv ", currPosition.x + tA, currPosition.y + 2.2f* textHelper);
          } else if(hsbBool[1] == 1){
            text("Saturation-Modus ist aktiv", currPosition.x + tA, currPosition.y + 2.2f* textHelper);
          } else if(hsbBool[2] == 1){
            text("Brigthness-Modus ist aktiv", currPosition.x + tA, currPosition.y + 2.2f* textHelper);
          }
            
          text("Stärke: " + nf(strength,1,2), currPosition.x + tA, currPosition.y + 3.2f* textHelper);
          text("Auto-Stärke: " + nf(autoStrength,1,2), currPosition.x + tA, currPosition.y + 4.2f* textHelper);
          break;
      }
  }
  
  public void changeActive(){
    this.active = !this.active;
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Abgabe" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
